/bin/rm -rf pypi-shadow3
git clone https://github.com/radiasoft/pypi-shadow3
cd pypi-shadow3

