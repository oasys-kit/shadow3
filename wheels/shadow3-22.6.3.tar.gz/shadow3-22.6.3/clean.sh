/bin/rm -rf ./shadow3.egg-info
/bin/rm -rf ./build
/bin/rm -rf ./dist
