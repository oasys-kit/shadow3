=====================
SHADOW3 DOCUMENTATION
=====================

This folder contains the input files for running all the examples of the 
Shadow3 Primer


The primer is available at: 

http://ftp.esrf.eu/pub/scisoft/shadow3/Shadow3Primer.pdf

For running everything use the primer.sh script

Tested in Linux using gnuplot 4.4 patchlevel 3

In addition to the .inp files, for running shadow in command mode, there are
other files for running the examples in other shadow environments:
   .ws files: workspaces for shadowvui
   .py files: python scripts

srio@esrf.eu  2011-01-06. Updated 2015-04-17

